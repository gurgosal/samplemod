import sys
import importlib
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import matplotlib
from sklearn.externals import joblib
matplotlib.rcParams.update({'figure.autolayout': True})
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from pymongo import MongoClient

import sys
sys.path.append('./src/Data_Preprocessing')
from DataCleaningRaw import DataCleaningRaw
from ParsingNLP import ParsingNLP
from data_collection import collection_ML

# get unlabeled products from mongo
client = MongoClient('mongodb://spark:hg7iib8w@34.207.228.12:27017')
# print client.database_names()
db = client.dg
# db.authenticate('spark', 'hg7iib8w', mechanism ='MONGODB-CR')
collections_db = db.collection_names()
collec_1 = db.unlabeled_products
cursor = collec_1.find()
df_database = pd.DataFrame(list(cursor))


if __name__ == '__main__':

    # load trained model from Models directory
    model_1 = joblib.load(open('./src/Models/ali_model_with wishali_data_RF/'
                               'model_for_ali_trained_with_wish_and_ali_RF_.pkl'))
    # model_2 = joblib.load(open('/Users/gurpreetgosal/Dropbox/Work_DG/Product_category/Models/wish_model/'
    #                            'model_runwith_wishdata_RF2_.pkl'))
    models = [model_1]

    # import new data
    test_new =  df_database
    data_arch = df_database

    # preprocess test data
    test_new_X  = collection_ML.data_prep(test_new, ali = 0, wish = 1)

    le1 = preprocessing.LabelEncoder()
    le1.classes_ = np.load('./src/Models/ali_model_with wishali_data_RF/classes_RF_ali_wish_feb12_1.npy')
    le = [le1]

    y_pred = np.asarray(list(le[0].inverse_transform(models[0].predict(test_new_X))))
    out_df = data_arch
    out_df['PredictedCategory'] = y_pred
    # upfate collection
    
    out_file = '/Users/gurpreetgosal/Dropbox/Work_DG/Product_category/Prediction Data/' \
               'wish_ulamore_categories_' + str(0) + '.csv'

    out_df.to_csv(out_file, sep=',')










